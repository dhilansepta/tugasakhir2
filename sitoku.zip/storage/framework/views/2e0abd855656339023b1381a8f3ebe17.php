<div class="modal fade" id="<?php echo $__env->yieldContent('modal-id'); ?>" tabindex="-1" aria-labelledby="<?php echo $__env->yieldContent('modal-label'); ?>" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="<?php echo $__env->yieldContent('modal-label'); ?>"><?php echo $__env->yieldContent('modal-title'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <?php echo $__env->yieldContent('modal-body'); ?>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/layouts/modal-layout.blade.php ENDPATH**/ ?>