@extends('layouts.karyawanlayout')

@section('title', 'Dashboard Karyawan')

@section('dashboard-link', 'active')

@section('content')

@endsection