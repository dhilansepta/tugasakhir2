<?php

namespace App\Http\Controllers;

use App\Models\BarangMasuk;
use App\Models\LaporanStokBarang;
use Illuminate\Http\Request;

class FilterTanggalController extends Controller
{
    
}
