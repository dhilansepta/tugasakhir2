

<?php $__env->startSection('title', 'Dashboard Karyawan'); ?>

<?php $__env->startSection('dashboard-link', 'active'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.karyawanlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/karyawan/dashboard.blade.php ENDPATH**/ ?>