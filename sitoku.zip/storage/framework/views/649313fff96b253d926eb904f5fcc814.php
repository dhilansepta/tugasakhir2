

<?php $__env->startSection('title', 'Kategori Barang'); ?>

<?php $__env->startSection('lain-link', 'active'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid pt-4 px-4">
    <div class="g-4">
        <div class="d-flex flex-row align-items-end justify-content-between">
            <h3 id="judul">Data Kategori Barang</h3>
            <button class="btn btn-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#tambahKategoriModal">
                Tambah Kategori
            </button>
        </div>

        <?php echo $__env->make('layouts.partials.modaladd.kategori', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.partials.modaledit.kategori', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="d-flex flex-column bd-highlight bg-secondary rounded p-3 mt-3">
            <div class="d-flex flex-row align-items-end justify-content-between mb-2">
                <div>
                    Cari
                </div>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Nama Kategori</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($data->id); ?></td>
                            <td><?php echo e($data->kategori); ?></td>
                            <td>
                                <a class="btn btn-sm btn-warning mx-2 btn-edit"
                                    href="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#editKategoriModal"
                                    data-id="<?php echo e($data->id); ?>"
                                    data-name="<?php echo e($data->kategori); ?>">
                                    Edit
                                </a>
                                <a class="btn btn-sm btn-warning mx-2 btn-danger">
                                    Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center text-mute" colspan="4">Data Satuan tidak tersedia</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Tangkap semua tombol edit
        var editButtons = document.querySelectorAll('.btn-edit');

        editButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                var dataId = this.getAttribute('data-id');
                var dataKategori = this.getAttribute('data-name');

                // Isi form dengan data user
                document.getElementById('edit_kategori').value = dataKategori;

                // Set action URL untuk form
                var form = document.getElementById('editKategoriForm');
                form.action = '/edit-kategoribarang/' + dataId;
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ownerlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/owner/kategoribarang.blade.php ENDPATH**/ ?>