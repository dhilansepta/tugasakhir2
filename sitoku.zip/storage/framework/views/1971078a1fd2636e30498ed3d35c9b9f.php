

<?php $__env->startSection('modal-id', 'tambahAkunModal'); ?>
<?php $__env->startSection('modal-label', 'tambahAkunModalLabel'); ?>
<?php $__env->startSection('modal-title', 'Tambah Akun Baru'); ?>
<?php $__env->startSection('modal-body'); ?>

<div class="modal-body">
    <form method="POST" action="<?php echo e(route('manage.store-account')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Nama</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label for="role" class="form-label">Role</label>
            <select class="form-select" id="role" name="role" required>
                <option value="" selected disabled hidden>Pilih Role</option>
                <option value="Owner">Owner</option>
                <option value="Karyawan">Karyawan</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>

        <div class="mb-3">
            <label for="password-confirmation" class="form-label">Konfirmasi Password</label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required autocomplete="new-password">
        </div>

        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" id="status" name="status" required>
                <option value="" selected disabled hidden>Pilih Status</option>
                <option value="Aktif">Aktif</option>
                <option value="Non_Aktif">Non_Aktif</option>
            </select>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-success">Simpan</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modal-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/layouts/partials/modal-add/akun.blade.php ENDPATH**/ ?>