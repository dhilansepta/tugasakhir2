

<?php $__env->startSection('modal-id', 'editAkunModal'); ?>
<?php $__env->startSection('modal-label', 'editAkunModalLabel'); ?>
<?php $__env->startSection('modal-title', 'Edit Data Akun'); ?>

<?php $__env->startSection('modal-body'); ?>
<div class="modal-body">
    <span>test</span>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.modal-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/layouts/partials/modal-edit/akun.blade.php ENDPATH**/ ?>